package Assignmentuser2;

public class dept {

}
